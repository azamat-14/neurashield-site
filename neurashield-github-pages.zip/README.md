# NeuraShield — AI & Cyber Security

A responsive single-page website built with HTML, CSS, and a little JavaScript.

## Run locally
Open `index.html` in your browser.

## Publish with GitHub Pages
1. Create a new public repository on GitHub (for example, `neurashield-site`).
2. Upload `index.html` to the repository root and commit the changes.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for GitHub Pages to publish the site. The URL will appear in Settings → Pages and usually looks like `https://YOUR-USERNAME.github.io/neurashield-site/`.

Replace `YOUR-USERNAME` with your GitHub username. GitHub Pages may take a few minutes to publish.
